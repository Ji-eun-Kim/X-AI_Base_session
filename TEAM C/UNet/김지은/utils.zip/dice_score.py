import torch
from torch import Tensor


def dice_coeff(input: Tensor, target: Tensor, reduce_batch_first: bool = False, epsilon: float = 1e-6):
    #모든 배치 또는 단일 마스크에 대한 dice 개수의 평균
    # Average of Dice coefficient for all batches, or for a single mask
    assert input.size() == target.size()
    assert input.dim() == 3 or not reduce_batch_first

    sum_dim = (-1, -2) if input.dim() == 2 or not reduce_batch_first else (-1, -2, -3)
    #reduce_batch_first가 False인 경우 3차원, True인 경우 2차원 할당

    #IOU와 비슷한 개념
    inter = 2 * (input * target).sum(dim=sum_dim)
    #교집합
    sets_sum = input.sum(dim=sum_dim) + target.sum(dim=sum_dim)
    #합집합
    sets_sum = torch.where(sets_sum == 0, inter, sets_sum)
    #합집합이 0인 경우, 교집합 값 대입

    dice = (inter + epsilon) / (sets_sum + epsilon)
    return dice.mean()

#모든 클래스에 대한 dice 개수의 평균
def multiclass_dice_coeff(input: Tensor, target: Tensor, reduce_batch_first: bool = False, epsilon: float = 1e-6):
    # Average of Dice coefficient for all classes
    return dice_coeff(input.flatten(0, 1), target.flatten(0, 1), reduce_batch_first, epsilon)


#0과 1 사이의 dice 손실값
def dice_loss(input: Tensor, target: Tensor, multiclass: bool = False):
    # Dice loss (objective to minimize) between 0 and 1
    fn = multiclass_dice_coeff if multiclass else dice_coeff
    return 1 - fn(input, target, reduce_batch_first=True)
